export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyC53TnjmFfHYmxvPpn9sEHCQuRZkiRPbTE",
    authDomain: "parkduocuc.firebaseapp.com",
    projectId: "parkduocuc",
    storageBucket: "parkduocuc.appspot.com",
    messagingSenderId: "206382098465",
    appId: "1:206382098465:web:9c3a53237e7b6e8ae15b60",
    measurementId: "G-5PW2D6B6YX"
  }
};
