import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { AngularFireAuth } from '@angular/fire/compat/auth';

@Injectable({
  providedIn: 'root',
})
export class AdminGuard implements CanActivate {
  constructor(private afAuth: AngularFireAuth, private router: Router) {}

  async canActivate(): Promise<boolean> {
    const user = await this.afAuth.currentUser;

    if (user?.email === 'admin@duoc.cl') {
      return true; // Permite el acceso
    } else {
      this.router.navigate(['/home']); // Redirige al home si no es administrador
      return false;
    }
  }
}
