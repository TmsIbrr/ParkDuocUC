import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { Observable } from 'rxjs';
import { Reserva } from '../models/reserva.model';
import { filter } from 'rxjs';
import { collection, addDoc, doc, updateDoc, deleteDoc, getDocs, getDoc, onSnapshot } from 'firebase/firestore';
import { map } from 'rxjs/operators';
import { Timestamp } from '@angular/fire/firestore';

@Injectable({
  providedIn: 'root',
})
export class ReservaService {
  private collectionName = 'reservas'

  constructor(private firestore: AngularFirestore) {}

  async reservaExiste(id: string): Promise<boolean> {
    const docRef = this.firestore.doc(`reservas/${id}`);
    const snapshot = await docRef.get().toPromise();
    return snapshot ? snapshot.exists : false
  }


  // Obtener todas las reservas
  obtenerReservas(): Observable<Reserva[]> {
    return this.firestore
      .collection<Reserva>('reserva')
      .valueChanges({ idField: 'id' });
  }

  // Agregar reserva
  agregarReserva(reserva: Reserva) {
    return this.firestore.collection('reserva').add(reserva);
  }

  // Actualizar reserva
  async updateReserva(id: string, data: Partial<Reserva>): Promise<void> {
    return this.firestore
      .collection(this.collectionName)
      .doc(id)
      .update(data);
  }

  // Eliminar reserva
  deleteReserva(id: string) {
    return this.firestore.collection('reserva').doc(id).delete();
  }

  // Obtener reserva por ID
  getReservaById(id: string): Observable<Reserva> {
    return this.firestore
      .collection<Reserva>(this.collectionName)
      .doc(id)
      .valueChanges() as Observable<Reserva>;
  }



getReservasObservable(): Observable<Reserva[]> {
  return this.firestore
    .collection<Reserva>('reserva')
    .valueChanges({ idField: 'id' })
    .pipe(
      map((reservas) =>
        reservas.map((reserva) => ({
          ...reserva,
          hora_llegada: reserva.hora_llegada instanceof Timestamp
            ? reserva.hora_llegada.toDate() // Convierte Timestamp a Date
            : reserva.hora_llegada,
          hora_salida: reserva.hora_salida instanceof Timestamp
            ? reserva.hora_salida.toDate()
            : reserva.hora_salida,
        }))
      )
    );
}

  
}
