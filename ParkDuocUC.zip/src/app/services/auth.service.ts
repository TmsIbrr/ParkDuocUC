import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private email: string = '';

  constructor() {}

  // Método para establecer el correo electrónico
  setEmail(email: string): void {
    this.email = email;
  }

  // Método para verificar si es admin
  isAdmin(): boolean {
    return this.email.toLowerCase() === 'admin@duoc.cl';
  }
}
